{{/*
Expand the name of the chart.
*/}}
{{- define "testgen.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "testgen.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "testgen.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "testgen.labels" -}}
helm.sh/chart: {{ include "testgen.chart" . }}
{{ include "testgen.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.testgen.labels }}
{{- toYaml . | nindent 0 }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "testgen.selectorLabels" -}}
app.kubernetes.io/name: {{ include "testgen.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "testgen.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "testgen.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Render a probe from values. When testgen.uiBaseUrl has a path, the UI health check path moves under it.
*/}}
{{- define "testgen.probe" -}}
{{- $probe := deepCopy .probe -}}
{{- $url := urlParse (.root.Values.testgen.uiBaseUrl | default "") -}}
{{- $uiPath := trimSuffix "/" $url.path -}}
{{- if and $url.scheme $url.host $uiPath $probe.httpGet (eq ($probe.httpGet.path | default "") "/_stcore/health") -}}
{{- $_ := set $probe.httpGet "path" (printf "%s/_stcore/health" $uiPath) -}}
{{- end -}}
{{- toYaml $probe -}}
{{- end -}}
